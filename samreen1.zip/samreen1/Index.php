<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Document Generator</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-expand-md navbar-light bg-light fixed-top">
	<div class="container-fluid">
		<a class="navbar-brand" href="#"><img src="img/d91.png"></a>
		<button class="navbar-toggler" type="button" data-toggle="collaspse" data-target="navbarResponsive">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collaspse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
					<a id="home_btn" class="nav-link" href="#slides">Home</a>
				</li>
				<li class="nav-item">
					<a id="about_btn" class="nav-link" href="#about">About</a>
				</li>
				<li class="nav-item">
					<a id="service_btn" class="nav-link" href="#services">Services</a>
				</li>
				<li class="nav-item">
					<a id="team_btn" class="nav-link" href="#team">Team</a>
				</li>
				<li class="nav-item">
					<a id="connect_btn" class="nav-link" href="#connect">Contact</a>
				</li>
				<li class="nav-item">
					<a id="login_btn" class="nav-link" href="user/login.php">Login</a>
				</li>
				<li class="nav-item">
					<a id="registration_btn" class="nav-link" href="user/register.php">Registration</a>
				</li>
				<!-- GTranslate: https://gtranslate.io/ -->
<a href="#" onclick="doGTranslate('en|en');return false;" title="English" class="gflag nturl" style="background-position:-0px -0px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="English" /></a><a href="#" onclick="doGTranslate('en|fr');return false;" title="French" class="gflag nturl" style="background-position:-200px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="French" /></a><a href="#" onclick="doGTranslate('en|de');return false;" title="German" class="gflag nturl" style="background-position:-300px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="German" /></a><a href="#" onclick="doGTranslate('en|it');return false;" title="Italian" class="gflag nturl" style="background-position:-600px -100px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Italian" /></a><a href="#" onclick="doGTranslate('en|pt');return false;" title="Portuguese" class="gflag nturl" style="background-position:-300px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Portuguese" /></a><a href="#" onclick="doGTranslate('en|ru');return false;" title="Russian" class="gflag nturl" style="background-position:-500px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Russian" /></a><a href="#" onclick="doGTranslate('en|es');return false;" title="Spanish" class="gflag nturl" style="background-position:-600px -200px;"><img src="//gtranslate.net/flags/blank.png" height="16" width="16" alt="Spanish" /></a>

<style type="text/css">
<!--
a.gflag {vertical-align:middle;font-size:16px;padding:1px 0;background-repeat:no-repeat;background-image:url(//gtranslate.net/flags/16.png);}
a.gflag img {border:0;}
a.gflag:hover {background-image:url(//gtranslate.net/flags/16a.png);}
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
-->
</style>

<br /><select onchange="doGTranslate(this);"><option value="">Select Language</option><option value="en|af">Afrikaans</option><option value="en|sq">Albanian</option><option value="en|ar">Arabic</option><option value="en|hy">Armenian</option><option value="en|az">Azerbaijani</option><option value="en|eu">Basque</option><option value="en|be">Belarusian</option><option value="en|bg">Bulgarian</option><option value="en|ca">Catalan</option><option value="en|zh-CN">Chinese (Simplified)</option><option value="en|zh-TW">Chinese (Traditional)</option><option value="en|hr">Croatian</option><option value="en|cs">Czech</option><option value="en|da">Danish</option><option value="en|nl">Dutch</option><option value="en|en">English</option><option value="en|et">Estonian</option><option value="en|tl">Filipino</option><option value="en|fi">Finnish</option><option value="en|fr">French</option><option value="en|gl">Galician</option><option value="en|ka">Georgian</option><option value="en|de">German</option><option value="en|el">Greek</option><option value="en|ht">Haitian Creole</option><option value="en|iw">Hebrew</option><option value="en|hi">Hindi</option><option value="en|hu">Hungarian</option><option value="en|is">Icelandic</option><option value="en|id">Indonesian</option><option value="en|ga">Irish</option><option value="en|it">Italian</option><option value="en|ja">Japanese</option><option value="en|ko">Korean</option><option value="en|lv">Latvian</option><option value="en|lt">Lithuanian</option><option value="en|mk">Macedonian</option><option value="en|ms">Malay</option><option value="en|mt">Maltese</option><option value="en|no">Norwegian</option><option value="en|fa">Persian</option><option value="en|pl">Polish</option><option value="en|pt">Portuguese</option><option value="en|ro">Romanian</option><option value="en|ru">Russian</option><option value="en|sr">Serbian</option><option value="en|sk">Slovak</option><option value="en|sl">Slovenian</option><option value="en|es">Spanish</option><option value="en|sw">Swahili</option><option value="en|sv">Swedish</option><option value="en|th">Thai</option><option value="en|tr">Turkish</option><option value="en|uk">Ukrainian</option><option value="en|ur">Urdu</option><option value="en|vi">Vietnamese</option><option value="en|cy">Welsh</option><option value="en|yi">Yiddish</option><option value="en|bn">Bengali</option><option value="en|gu">Gujarati</option><option value="en|kn">Kannada</option><option value="en|mr">Marathi</option><option value="en|mn">Mongolian</option><option value="en|ne">Nepali</option><option value="en|pa">Punjabi</option><option value="en|so">Somali</option><option value="en|ta">Tamil</option><option value="en|te">Telugu</option></select><div id="google_translate_element2"></div>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'en',autoDisplay: false}, 'google_translate_element2');}
</script><script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>


<script type="text/javascript">
/* <![CDATA[ */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',43,43,'||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'.split('|'),0,{}))
/* ]]> */
</script>
</a>
			</ul>
		</div>
	</div>
</nav>


<!--- Image Slider -->
<div id="slides" class="carousel slide" data-ride="carousel">
	<ul class="carousel-indicators">
		<li data-target="#slides" data-slide-to="0" class="active"></li>
		<li data-target="#slides" data-slide-to="1"></li>
		<li data-target="#slides" data-slide-to="2"></li>
		<li data-target="#slides" data-slide-to="3"></li>
	</ul>
	<div class="carousel-inner">
		<div class="carousel-item active">
			<img src="img/pic1.jpg">
			<div class="carousel-caption">
				<h1 class="display-2">Document Generator</h1>
				<h3>We Make Online Or E-Documents.</h3>
				<button type="button" class="btn btn-info btn-primary btn-lg"> Sign In</button>
				<button type="button" class="btn btn-primary btn-lg">Register Now!</button>
			</div>
		</div>
		<div class="carousel-item">
			<img src="img/pic2.jpg">
			    <div class="carousel-caption">
				<h3>We Provide Best Guidance.</h3></div>
			</div>
		<div class="carousel-item">
			<img src="img/pic3.jpg">
			<div class="carousel-caption">
			<h3>Time Saving.</h3></div>
		</div>
		<div class="carousel-item">
			<img src="img/pic4.jpg">
			<div class="carousel-caption">
			<h3>Thousand Queries A Single Solution.</h3></div>
		</div>
	</div>
</div>




<!--- Jumbotron -->
<div class="container-fluid">
	<div class="row jumbotron">
		<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-10">
			<p class="lead"><b>Did You Know ?</b><br>
				Furnishing father's name in PAN application is not mandatory.<br>
				Earlier, applicants were required to furnish father's name in PAN application form which was also printed on the PAN card.
                However, as per a new rule which came into effect on 5 Dec'18, applicants can now choose whether they want the name of their father or mother on the card.If the applicant's mother is a single parent, furnishing father's name isn't mandatory.

			 </p>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-2">
			<a href="#"><button type="button" class="btn btn-outline-secondary btn-lg">Learn More
			</button></a>
		</div>
	</div>
</div>

<!---welcome section of about---->

<div class="container-fluid padding" id="about">
	<div class="row welcome text-center">
		<div class="col-12">
			<h1 class="display-4"> About Us.</h1>
		</div>
		<hr>
		<div class="col-12">
			<p class="lead">
			Document Generator is a website that allows you learn about and to create various documents easily.The issue of proper documentation and verification of various documents causes trouble to both students and adults all over India. Therefore we intend to create a website that will act as a platform for uploading and submission of the required documents to the associated office </p>
			
		</div>
	</div>
</div>

<!--About Section -->
<div class="row about-cols">

          <div class="col-md-4 wow fadeInUp">
            <div class="about-col">
              <div class="img">
                <img src="img/mission.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-speedometer-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Mission</a></h2>
              <p>
                To serve our customers to the best by delivering all the documents in a safe and secure way,while ensuring exceptional customer support throughout the process. We aim to build longlasting relationship with our clients.
              </p>
            </div>
          </div>

          <div class="col-md-4 wow fadeInUp" data-wow-delay="0.1s">
            <div class="about-col">
              <div class="img">
                <img src="img/plan.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-list-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Plan</a></h2>
              <p>
                Our plan is simple, <br>We dream it,<br>We set goals for it,<br>We work hard for it and then <br>We make it happen.
              </p>
            </div>
          </div>

          <div class="col-md-4 wow fadeInUp" data-wow-delay="0.2s">
            <div class="about-col">
              <div class="img">
                <img src="img/vision.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-eye-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Vision</a></h2>
              <p>
                Our vision is to one day become more nationalized and provide our services all over India. We intend to earn love and respect while we offer our customers with the best service experience.
              </p>
            </div>
          </div>

        </div>

      </div>
      <!--- Welcome Section -->
<div class="container-fluid padding"  id="services">
	<div class="row welcome text-center">
		<div class="col-12">
			<h1 class="display-4"> Create Documents With Ease.</h1>
		</div>
		<hr>
		<div class="col-12">
			<p class="lead"> Welcome to Document Generator!
			Document Generator is a website that allows you learn about and to create various documents easily. The various document creation offered by us are:</p>
			
		</div>
	</div>
</div>

      <!--- Three Column Section -->
<div class="container-fluid padding">
	<div class="row text-center padding">
		<div class="col-xs-12 col-sm-6 col-md-4">
		  <i class="fas fa-birthday-cake"></i>
		  <h3> BIRTH CERTIFICATE</h3>
		  <p>A birth certificate is a vital record that documents the birth of a child. The term "birth certificate" can refer to either the original document certifying the circumstances of the birth or to a certified copy of or representation of the ensuing registration of that birth</p>
		</div>

          <div class="col-xs-12 col-sm-6 col-md-4">
		  <i class="far fa-address-card"></i>
		  <h3> PAN CARD</h3>
		  <p>A permanent account number (PAN) is a ten-character alphanumeric identifier, issued in the form of a laminated "PAN card", by the Indian Income Tax Department, to any "person" who applies for it or to whom the department allots the number without an application</p>
		</div>

		  <div class="col-sm-12 col-md-4">
		  <i class="fas fa-home"></i>
		  <h3> DOMICILE CERTIFICATE</h3>
		  <p>A Domicile/ Residence Certificate is issued to prove that the citizen has been continuously staying in the State for a period of 15 years. </p>

		  <a href="doc.php" class="btn btn-primary"> Learn More About Other Documents</a>
		</div>
	</div>
	<hr class="my-4">
</div>

<!--- Two Column Section -->
<div class="container-fluid padding">
	<div class="row padding">
		<div class="col-lg-6">
			<h2>If you want to create Birth Certificate of your new born....</h2>
			<p>Step 1: Get a birth Certificate Registration Form from the registrar's office (from your municipal authority).
            <p>Step 2: When a child is born in a hospital, the form is provided by the Medical Officer In-charge.</p>
            <p> Step 3: Fill in the form within 21 days of birth of the child.</p>
            <br>
            <a href="birth.html" class="btn btn-primary"> Learn More</a>
        </div>
        <div class="col-lg-6"></div>
        <img src="img/desk.png" class="img-fluid">
	</div>
</div>
<hr class="my-4">
<!--- Fixed background -->
<figure>
	<div class="fixed-wrap">
		<div id="fixed"></div>
	</div>
</figure>
<!--- Emoji Section -->

<!--- Meet the team -->
<div class="container-fluid padding" id="team">
	<div class="row welcome text-center">
		<div class="col-12">
			<h1 class="display-4"> Meet the Team</h1>
		</div>
		<hr>
		</div>
	</div>

<!--- Cards -->
<div class="container-fluid padding" >
	<div class="row padding">
      <div class="col-md-4">
      	<div class="card">
      		<img class="card-img-top" src="img/team1.png">
      		<div class="card-body">
      			<h4 class="card-title"> Samrat Tilakdhari</h4>
      			<p class="card-text">Samrat Tilakdhari is our reputable agent who has skills that match no other and has been working in this field for past 5 years.  </p>
      			<a href="#" class="btn btn-outline-secondary">See Profile</a>
      		</div>
      	</div>
      </div>	

<div class="col-md-4">
      	<div class="card">
      		<img class="card-img-top" src="img/team2.png">
      		<div class="card-body">
      			<h4 class="card-title"> Aishwarya Swami</h4>
      			<p class="card-text">Aishwarya Swami is a bright and intellectual employee, who is responsible for editing and has been working for 8 years.</p>
      			<a href="#" class="btn btn-outline-secondary">See Profile</a>
      		</div>
      	</div>
      </div>	

<div class="col-md-4">
      	<div class="card">
      		<img class="card-img-top" src="img/team3.png">
      		<div class="card-body">
      			<h4 class="card-title">Jeet Khurana</h4>
      			<p class="card-text">Jeet Khurana is the manager of the team and does all the technical work.</p>
      			<a href="#" class="btn btn-outline-secondary">See Profile</a>
      		</div>
      	</div>
      </div>	

	</div>
	<hr class="my-4">
</div>

<!--- Two Column Section -->

<!--- Connect -->

<div class="container-fluid padding" id="connect">
	<div class="row text-center padding">
		<div class="col-12">
			<h2 class="con1"> Connect</h2>
		</div>
		<div class="col-12 social padding">
			<a href="#"><i class="fab fa-facebook"></i></a>
			<a href="#"><i class="fab fa-twitter"></i></a>
			<a href="#"><i class="fab fa-google-plus-g"></i></a>
			<a href="#"><i class="fab fa-instagram"></i></a>
			<a href="#"><i class="fab fa-youtube"></i></a>
		</div>
	</div>
</div>


<!--- Footer -->
<footer>
	<div class="container-fluid padding">
		<div class="row text-center">
			<div class="col-md-4">
				<img src="img/d91.png">
				<hr class="light">
				<p>1234567890</p>
				<p>documentgenerator@gmail.com</p>
				<p>Bandra (West)</p>
		</div>
		<div class="col-md-4">
			<hr class="light">
			<h5> Our Hours</h5>
			<hr class="light">
			<p> Monday: 9am - 5pm</p>
			<p> Saturday: 10am - 4pm</p>
			<p> Sunday: closed</p>
		</div>
		<div class="col-md-4">
			<hr class="light">
			<h5> Service Areas</h5>
			<hr class="light">
			<p> Lokhandwala</p>
			<p> Vashi</p>
			<p> Fort</p>
		</div>
		<div class="col-12">
			<hr class="light-100">
			<h5>&copy;documentgenerator.com</h5>
		</div>
	</div>
</div>
</footer>
</body>
</html>


















