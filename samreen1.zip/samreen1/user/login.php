<?php include "./templates/top.php"; ?>

<?php include "./templates/navbar.php"; ?>
<body style="background:url('images/pic1.jpeg'); background-size: cover;">
<div class="container">
	<div class="row justify-content-center" style="margin:100px 0;">
		<div class="col-md-4">
			<h4><center><font color="#fff">User Login</center></font></h4>
			<p class="message"></p>
			<form id="admin-login-form">
			  <div class="form-group">
			    <label for="email"><b><font color="#fff">Email address</b></font></label>
			    <input type="email" class="form-control" name="email" id="email"  placeholder="Enter email">
			    <small id="emailHelp" class="form-text text-muted"><font color="#fff">We'll never share your email with anyone else.</font></small>
			  </div>
			  <div class="form-group">
			    <label for="password"><b><font color="#fff">Password</b></font></label>
			    <input type="password" class="form-control" name="password" id="password" placeholder="Password">
			  </div>
			  <input type="hidden" name="admin_login" value="1">
			  <center>
			  <button type="button" class="btn btn-primary login-btn">Submit</button></center>
			</form>
		</div>
	</div>
</div>
</body>




<?php include "./templates/footer.php"; ?>

<script type="text/javascript" src="./js/main.js"></script>
