<?php
 include "./templates/navbar1.php";

$con=mysqli_connect("localhost","root","","file");
if(isset ($_REQUEST["submit"]))
{
	$user=$_REQUEST["user"];
	$file=$_FILES["file"]["name"];
	$tmp_name=$_FILES["file"]["tmp_name"];
	$path="suppan/".$file;
	move_uploaded_file($tmp_name,$path);
	$query=("insert into suppan(user,file) values('$user','$file')");
	mysqli_query($con,$query); 

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Pan Card</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style1.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>
<body>

<br>
<br>

<h1><center><font color="#FF337D">Upload Supporting Pan Card Documents Here </font></center></h1>
<br>
<br>
<form enctype="multipart/form-data" method="post">
<center>
	<b>Full Name</b>
	<input type="text" name="user" class="form-control-sm" aria-describedby="userhelp"placeholder="Enter Full Name"><br><br>
	
	<b>Upload Aadhar Card/Passport Here </b>
	<small id="userhelp" class="form-text text-muted">Please Rename the pdf file to your full name.</small>
	<br>
	<input type="file" name="file"><br><br>
	<input type="submit" name="submit" value="Upload" class="btn btn-primary"></center>
</form>
</body>
</html>