<?php
$con=mysqli_connect("localhost","root","","file");
$query=mysqli_query($con,"select * from supcaste");
$rowcount=mysqli_num_rows($query);
?><!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
	<title>Admin Panel</title>
</head>
<body>
<table border="1" class="table">
	<thead class="thead-dark">
<tr>
<th>Full Name Of Customer</th>
<th>Download the Supporting Documents</th>
</tr>
</thead>
<?php
for($i=1;$i<=$rowcount;$i++)
{
	$row=mysqli_fetch_array($query);

?>

<tr>
<td><?php echo $row["user"] ?>
</td>
<td><br><a href="supcaste/<?php echo $row["file"] ?>"><?php echo $row["file"] ?></a></td>

</tr>

<?php	
}

?>
</table>
</body>
</html>
