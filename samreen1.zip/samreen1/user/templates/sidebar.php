<nav class="col-md-2 d-none d-md-block bg-light sidebar">
      <div class="sidebar-sticky">
        <ul class="nav flex-column">

          <?php 


            $uri = $_SERVER['REQUEST_URI']; 
            $uriAr = explode("/", $uri);
            $page = end($uriAr);

          ?>


          <li class="nav-item">
            <a class="nav-link <?php echo ($page == '' || $page == 'index.php') ? 'active' : ''; ?>" href="index.php">
              <span data-feather="home"></span>
              Dashboard <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'download.php') ? 'active' : ''; ?>" href="download.php">
              <span data-feather="file"></span>
              Document Lists
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'birth.php') ? 'active' : ''; ?>" href="birth.php">
              <span data-feather="file"></span>
              Birth Certificate
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'domicile.php') ? 'active' : ''; ?>" href="domicile.php">
              <span data-feather="file"></span>
              Domicile Certificate
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'pan.php') ? 'active' : ''; ?>" href="pan.php">
              <span data-feather="file"></span>
              Pan Card
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'caste.php') ? 'active' : ''; ?>" href="caste.php">
              <span data-feather="file"></span>
              Caste Certificate
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'income.php') ? 'active' : ''; ?>" href="income.php">
              <span data-feather="file"></span>
              Income Certificate
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'noncreamy.php') ? 'active' : ''; ?>" href="noncreamy.php">
              <span data-feather="file"></span>
              Non Creamy Layer
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'supbirth.php') ? 'active' : ''; ?>" href="supbirth.php">
              <span data-feather="file"></span>
             Upload Supporting Birth Certificate Documents
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'supdomicile.php') ? 'active' : ''; ?>" href="supdomicile.php">
              <span data-feather="file"></span>
             Upload Supporting Domicile Certificate Documents
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'suppan.php') ? 'active' : ''; ?>" href="suppan.php">
              <span data-feather="file"></span>
              Upload Supporting Pan Card Documents
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'supcaste.php') ? 'active' : ''; ?>" href="supcaste.php">
              <span data-feather="file"></span>
              Upload Supporting Caste Certificate Documents
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'supincome.php') ? 'active' : ''; ?>" href="supincome.php">
              <span data-feather="file"></span>
             Upload Supporting Income Certificate Documents
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link <?php echo ($page == 'supnoncreamy.php') ? 'active' : ''; ?>" href="supnoncreamy.php">
              <span data-feather="file"></span>
             Upload Supporting Non Creamy Layer Documents
            </a>
          </li>
        </ul>

       
      </div>
    </nav>
<br>
<br>

    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Hello <?php echo $_SESSION["admin_name"]; ?></h1>
      </div>
      	<div class="col-12">
			<p class="lead">
			Document Generator is a website that allows you learn about and to create various documents easily.
		    The issue of proper documentation and verification of various documents causes trouble to both students and adults all over India. Therefore we intend to create a website that will act as a platform for uploading and submission of the required documents to the associated office. </p>
			<img src="img/bc.png">
			<img src="img/cc.png">
			<img src="img/domicile.png">
			<img src="img/ncl.png">
			<img src="img/pan.png">
			<center><img src="img/income.png"></center>
			
		</div>