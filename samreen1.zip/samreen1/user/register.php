<?php include "./templates/top.php"; ?>

<?php include "./templates/navbar.php"; ?>
<body style="background:url('images/pic1.jpeg'); background-size: cover;">
<div class="container">
	<div class="row justify-content-center" style="margin:100px 0;">
		<div class="col-md-4">
			<h4><font color="#fff"><center><b>User Registeration</b></center></font></h4>
			<p class="message"></p>
			<form id="admin-register-form">
			  <div class="form-group">
			    <label for="name"><font color="#fff">Name</font></label>
			    <input type="text" class="form-control" name="name" id="name" placeholder="Enter Name">
			  </div>
			  <div class="form-group">
			    <label for="email"><font color="#fff">Email address</font></label>
			    <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
			    <small id="emailHelp" class="form-text text-muted"><font color="#fff">We'll never share your email with anyone else.</small>
			  </div>
               <div class="form-group">
			    <label for="mobile"><font color="#fff">Mobile</font></label>
			    <input type="text" class="form-control" name="mobile" id="mobile" placeholder="Enter Mobile">
			  </div>
			   <div class="form-group">
			    <label for="address"><font color="#fff">Address</font></label><br>
			    <textarea rows="5" cols="30" name="address" id="address"></textarea>
			  </div>			   
			  <div class="form-group">
			    <label for="password"><font color="#fff">Password</font></label>
			    <input type="password" class="form-control" name="password" id="password" placeholder="Password">
			  </div>
			  <div class="form-group">
			    <label for="cpassword"><font color="#fff">Confirm Password</font></label>
			    <input type="password" class="form-control" name="cpassword" id="cpassword" placeholder="Password">
			  </div>
			  <input type="hidden" name="admin_register" value="1">
			<center><button type="button" class="btn btn-primary register-btn">Register</button></center>
			</form>
		</div>
	</div>
</div>
</body>




<?php include "./templates/footer.php"; ?>

<script type="text/javascript" src="./js/main.js"></script>
