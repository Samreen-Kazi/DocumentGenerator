<?php
session_start();
$con=mysqli_connect("localhost","root","","doc_db");
if(isset($_POST['login_submit']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];
	$query="select * from logintb where username='$username' and password='$password';";
	$result=mysqli_query($con,$query);
	if(mysqli_num_rows($result)==1)
	{
		$_SESSION['username']=$username;
		header("Location:admin-panel.php");
	}
	else
		header("Location:error.php");
}
function display_admin_panel(){
	echo '<!DOCTYPE html>
<html lang="en">
  <head>
  <title> Admin Panel </title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style1.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <a class="navbar-brand" href="#"><i class="fa fa-user-plus" aria-hidden="true"></i>Document Generator</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
     <ul class="navbar-nav mr-auto">
       <li class="nav-item">
        <a class="nav-link" href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="#"></a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0" method="post" action="search.php">
      <input class="form-control mr-sm-2" type="text" placeholder="Enter Email" aria-label="Search" name="email">
      <input type="submit" class="btn btn-outline-light my-2 my-sm-0 btn btn-outline-light" id="inputbtn" name="search_submit" value="Search">
    </form>
  </div>
</nav>
  </head>

  <style type="text/css">
    button:hover{cursor:pointer;}
    #inputbtn:hover{cursor:pointer;}
  </style>
<body style="padding-top:50px;">
 <div class="jumbotron" id="ab1"></div>
<div class="container-fluid" style="margin-top:50px;">
    <div class="row">
<div class="col-md-4">
    <div class="list-group" id="list-tab" role="tablist">

       <a class="list-group-item list-group-item-action" id="list-attend-list" data-toggle="list" href="#list-attend" role="tab" aria-controls="settings">Customer Details</a>


       <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab" aria-controls="settings">Add Documents</a>

       <a class="list-group-item list-group-item-action" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="settings">User Filled Birth Certificate Form Download</a>

        <a class="list-group-item list-group-item-action" id="list-domicile-list" data-toggle="list" href="#list-domicile" role="tab" aria-controls="settings">User Filled Domicile Certificate Form Download</a>

        <a class="list-group-item list-group-item-action" id="list-pan-list" data-toggle="list" href="#list-pan" role="tab" aria-controls="settings">User Filled Pan Card Form Download</a>

         <a class="list-group-item list-group-item-action" id="list-caste-list" data-toggle="list" href="#list-caste" role="tab" aria-controls="settings">User Filled Caste Certificate Form Download</a>

          <a class="list-group-item list-group-item-action" id="list-income-list" data-toggle="list" href="#list-income" role="tab" aria-controls="settings">User Filled Income Certificate Form Download</a>

           <a class="list-group-item list-group-item-action" id="list-noncreamy-list" data-toggle="list" href="#list-noncreamy" role="tab" aria-controls="settings">User Filled Non Creamy Layer Form Download</a>






           <a class="list-group-item list-group-item-action" id="list-bc-list" data-toggle="list" href="#list-bc" role="tab" aria-controls="settings">Download Supporting Documents Of Birth Certificate</a>


           <a class="list-group-item list-group-item-action" id="list-dom-list" data-toggle="list" href="#list-dom" role="tab" aria-controls="settings">Download Supporting Documents Of Domicile Certificate</a>


           <a class="list-group-item list-group-item-action" id="list-pa-list" data-toggle="list" href="#list-pa" role="tab" aria-controls="settings">Download Supporting Documents Of Pan Card</a>


           <a class="list-group-item list-group-item-action" id="list-ca-list" data-toggle="list" href="#list-ca" role="tab" aria-controls="settings">Download Supporting Documents Of Caste Certificate</a>


           <a class="list-group-item list-group-item-action" id="list-in-list" data-toggle="list" href="#list-in" role="tab" aria-controls="settings">Download Supporting Documents Of Income Certificate</a>


           <a class="list-group-item list-group-item-action" id="list-non-list" data-toggle="list" href="#list-non" role="tab" aria-controls="settings">Download Supporting Documents Of Non Creamy Layer</a>

    </div><br>
  </div>



<div class="col-md-8">
<div class="tab-content" id="nav-tabContent">
<!--CustomerDetails-->
<div class="tab-pane fade" id="list-attend" role="tabpanel" aria-labelledby="list-attend-list">

<form class="form-group" method="post" action="cus.php">

<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here for Customer Details">
</form>
</div>


<div class="tab-pane fade" id="list-messages" role="tabpanel" aria-labelledby="list-messages-list">
<form class="form-group" method="post" action="upload.php">

<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Add Documents">
</form>
    </div>

<div class="tab-pane fade" id="list-home" role="tabpanel" aria-labelledby="list-home-list">
<form class="form-group" method="post" action="birthdown.php">

<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Birth Certificate Form">
</form>
    </div>


<div class="tab-pane fade" id="list-domicile" role="tabpanel" aria-labelledby="list-domicile-list">
<form class="form-group" method="post" action="domiciledown.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Domicile Certificate Form">
</form>
    </div>

  <div class="tab-pane fade" id="list-pan" role="tabpanel" aria-labelledby="list-pan-list">
<form class="form-group" method="post" action="pandown.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Pan Card Form">
</form>
    </div>

<div class="tab-pane fade" id="list-caste" role="tabpanel" aria-labelledby="list-caste-list">
<form class="form-group" method="post" action="castedown.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Caste Certificate Form">
</form>
    </div>

    <div class="tab-pane fade" id="list-income" role="tabpanel" aria-labelledby="list-income-list">
<form class="form-group" method="post" action="incomedown.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Income Certificate Form">
</form>
    </div>

    <div class="tab-pane fade" id="list-noncreamy" role="tabpanel" aria-labelledby="list-noncreamy-list">
<form class="form-group" method="post" action="noncreamydown.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Non Creamy Layer Form">
</form>
    </div>






      <div class="tab-pane fade" id="list-bc" role="tabpanel" aria-labelledby="list-bc-list">
<form class="form-group" method="post" action="supdownbirth.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Supporting Documents For Birth Certificate">
</form>
    </div>

  <div class="tab-pane fade" id="list-dom" role="tabpanel" aria-labelledby="list-dom-list">
<form class="form-group" method="post" action="supdowndomicile.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Supporting Documents For Domicile Certificate">
</form>
    </div>

  <div class="tab-pane fade" id="list-pa" role="tabpanel" aria-labelledby="list-pa-list">
<form class="form-group" method="post" action="supdownpan.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Supporting Documents For Pan Card">
</form>
    </div>

  <div class="tab-pane fade" id="list-ca" role="tabpanel" aria-labelledby="list-ca-list">
<form class="form-group" method="post" action="supdowncaste.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Supporting Documents For Caste Certificate">
</form>
    </div>

  <div class="tab-pane fade" id="list-in" role="tabpanel" aria-labelledby="list-in-list">
<form class="form-group" method="post" action="supdownincome.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Supporting Documents For Income Certificate">
</form>
    </div>

  <div class="tab-pane fade" id="list-non" role="tabpanel" aria-labelledby="list-non-list">
<form class="form-group" method="post" action="supdownnoncreamydown.php">
<input type="submit" class="btn btn-outline-dark my-2 my-sm-0 btn btn-outline-dark" id="inputbtn" name="customer" value="Click here to Download Supporting Documents For Non Creamy Layer">
</form>
    </div>













 </div>
</div>
   </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    <!--Sweet alert js-->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.1/sweetalert2.all.min.js"></script>
  </body>
</html>';
}
?>